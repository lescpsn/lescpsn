# -*- coding: utf8 -*-
import logging.config
import pymongo
import yaml
import tornado.httpserver
import tornado.ioloop
import tornado.web
from redis.sentinel import Sentinel
from tornado.httpclient import AsyncHTTPClient

from handlers.inbox import InboxHandler
from task.subscribe import SubscribeTask

__author__ = 'xinxin'

LOGO = r"""
__________
\______   \__ _________ __ __  ______
 |     ___/  |  \_  __ \  |  \/  ___/
 |    |   |  |  /|  | \/  |  /\___ \
 |____|   |____/ |__|  |____//____  >
                                  \/
"""

logger = logging.getLogger()


class Application(tornado.web.Application):
    def __init__(self):
        # Global config...
        self.config = yaml.load(open('config.yaml', 'r', encoding='utf8'))
        # adding downstream

        # logging...
        cfg = yaml.load(open('logging.yaml', 'r'))
        logging.config.dictConfig(cfg)

        handlers = [
            (r"/inbox", InboxHandler),

        ]

        settings = dict(
                debug=self.config['config']['debug'],
        )

        tornado.web.Application.__init__(self, handlers, **settings)

        sentinels = [(c['ip'], c['port']) for c in self.config['cache']]
        self.sentinel = Sentinel(sentinels, socket_timeout=0.1, db=15, decode_responses=True)
        self.port = self.config['config']['port']
        self.conn = pymongo.Connection("localhost", 27017)  # motor


if __name__ == "__main__":
    AsyncHTTPClient.configure(None, max_clients=400)
    print(LOGO)
    print("http://localhost:8888/inbox")

    app = Application()

    SubscribeTask(app, 10 * 1000).start()

    http_server = tornado.httpserver.HTTPServer(app, xheaders=True)
    http_server.listen(app.port)
    tornado.ioloop.IOLoop.instance().start()
