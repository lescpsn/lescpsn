# -*- coding: utf8 -*-
import logging
import tornado
import tornado.web
import tornado.gen
from core.mail import send_mail

__author__ = 'xinxin'

request_log = logging.getLogger("ms.request")

# 调用蝶信接口，发送短信
@tornado.gen.coroutine
def send_by_sms( application, msg, handler):
    pass


 # 调用邮件发送接口，发送邮件通知
@tornado.gen.coroutine
def send_by_email(application, msg, handler):
    send_account = 'wxx@e7chong.com'
    send_password = 'Wxx$123'
    send_smtp_address = 'smtp.exmail.qq.com'
    send_smtp_port = 465
    rev_list = [handler['address']]
    mail_title = '消息中心'
    mail_text = msg
    mail_file_list = ['F:\测试代码\logging.yaml']

    yield send_mail(application, send_account, send_password, send_smtp_address, send_smtp_port, rev_list, mail_title, mail_text, mail_file_list )



